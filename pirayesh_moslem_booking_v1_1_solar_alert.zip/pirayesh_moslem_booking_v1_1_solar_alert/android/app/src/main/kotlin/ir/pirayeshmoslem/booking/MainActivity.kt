package ir.pirayeshmoslem.booking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
