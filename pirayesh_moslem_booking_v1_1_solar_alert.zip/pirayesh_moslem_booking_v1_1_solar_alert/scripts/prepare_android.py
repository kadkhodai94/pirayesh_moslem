from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

manifest = ROOT / 'android/app/src/main/AndroidManifest.xml'
manifest.parent.mkdir(parents=True, exist_ok=True)
manifest.write_text('''<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:label="پیرایش مسلم"
        android:name="${applicationName}"
        android:icon="@mipmap/ic_launcher"
        android:usesCleartextTraffic="false">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
                android:name="io.flutter.embedding.android.NormalTheme"
                android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <meta-data android:name="flutterEmbedding" android:value="2" />
    </application>
</manifest>
''', encoding='utf-8')

main_activity = ROOT / 'android/app/src/main/kotlin/ir/pirayeshmoslem/booking/MainActivity.kt'
main_activity.parent.mkdir(parents=True, exist_ok=True)
main_activity.write_text('''package ir.pirayeshmoslem.booking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
''', encoding='utf-8')

build_gradle = ROOT / 'android/app/build.gradle'
if build_gradle.exists():
    text = build_gradle.read_text(encoding='utf-8')
    text = text.replace('namespace = "com.example.pirayesh_moslem_booking"', 'namespace = "ir.pirayeshmoslem.booking"')
    text = text.replace('applicationId = "com.example.pirayesh_moslem_booking"', 'applicationId = "ir.pirayeshmoslem.booking"')
    text = text.replace('applicationId "com.example.pirayesh_moslem_booking"', 'applicationId "ir.pirayeshmoslem.booking"')
    build_gradle.write_text(text, encoding='utf-8')
