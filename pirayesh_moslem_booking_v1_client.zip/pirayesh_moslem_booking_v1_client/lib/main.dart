import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(const PirayeshMoslemApp());
}


class PirayeshMoslemApp extends StatelessWidget {
  const PirayeshMoslemApp({super.key});

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFD8A847);
    const dark = Color(0xFF12100D);
    const cream = Color(0xFFF8F1E3);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'پیرایش مسلم',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.light,
          scaffoldBackgroundColor: cream,
          colorScheme: ColorScheme.fromSeed(
            seedColor: gold,
            primary: gold,
            secondary: const Color(0xFF6E4D1E),
            surface: const Color(0xFFFFFBF3),
          ),
          fontFamily: 'sans',
          appBarTheme: const AppBarTheme(
            centerTitle: true,
            backgroundColor: Colors.transparent,
            elevation: 0,
            foregroundColor: dark,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18),
              borderSide: const BorderSide(color: gold, width: 1.4),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
        builder: (context, child) => Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        ),
        home: const MoslemShell(),
      ),
    );
  }
}

class MoslemShell extends StatefulWidget {
  const MoslemShell({super.key});

  @override
  State<MoslemShell> createState() => _MoslemShellState();
}

class _MoslemShellState extends State<MoslemShell> {
  int _tab = 0;
  bool _adminLoggedIn = false;

  final List<ServiceItem> _services = [
    ServiceItem('کوتاهی مو', 'اصلاح تمیز و مرتب روزانه', 180000, 35, Icons.content_cut),
    ServiceItem('اصلاح ریش', 'خط ریش، مرتب‌سازی و فید صورت', 90000, 20, Icons.face_retouching_natural),
    ServiceItem('فید حرفه‌ای', 'فید تمیز با فرم‌دهی دقیق', 260000, 45, Icons.auto_awesome),
    ServiceItem('پکیج داماد', 'اصلاح کامل، ریش، فرم‌دهی و آماده‌سازی', 650000, 90, Icons.workspace_premium),
    ServiceItem('اصلاح کودک', 'نوبت سریع و آرام برای کودکان', 140000, 25, Icons.child_care),
  ];

  final List<Appointment> _appointments = [
    Appointment(
      id: 'M-1001',
      customerName: 'آرمان محمدی',
      mobile: '09120000001',
      serviceName: 'فید حرفه‌ای',
      price: 260000,
      date: _onlyDate(DateTime.now()),
      time: '18:00',
      status: AppointmentStatus.approved,
      points: 10,
    ),
    Appointment(
      id: 'M-1002',
      customerName: 'سامان کریمی',
      mobile: '09120000002',
      serviceName: 'اصلاح ریش',
      price: 90000,
      date: _onlyDate(DateTime.now()),
      time: '19:30',
      status: AppointmentStatus.pending,
      points: 0,
    ),
  ];

  final List<GalleryItem> _gallery = const [
    GalleryItem('فید تمیز', 'مدل پرطرفدار جوان‌ها', Icons.gradient),
    GalleryItem('کلاسیک مردانه', 'مرتب، رسمی و همیشه شیک', Icons.business_center),
    GalleryItem('ریش و خط صورت', 'فرم‌دهی دقیق و طبیعی', Icons.face),
    GalleryItem('داماد', 'آماده‌سازی کامل مراسم', Icons.diamond),
    GalleryItem('کودک', 'سریع، آرام و بدون استرس', Icons.child_friendly),
    GalleryItem('استایل روز', 'مدل‌های جدید منطقه', Icons.local_fire_department),
  ];

  static DateTime _onlyDate(DateTime value) => DateTime(value.year, value.month, value.day);

  void _addAppointment(Appointment appointment) {
    setState(() => _appointments.insert(0, appointment));
  }

  void _updateAppointmentStatus(Appointment appointment, AppointmentStatus status) {
    setState(() {
      final index = _appointments.indexWhere((item) => item.id == appointment.id);
      if (index == -1) return;
      _appointments[index] = appointment.copyWith(
        status: status,
        points: status == AppointmentStatus.approved ? 10 : appointment.points,
      );
    });
  }

  void _addService(ServiceItem service) {
    setState(() => _services.add(service));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(
        appointments: _appointments,
        services: _services,
        onBookNow: () => setState(() => _tab = 1),
      ),
      BookingScreen(
        services: _services,
        appointments: _appointments,
        onBooked: _addAppointment,
      ),
      GalleryScreen(items: _gallery),
      LoyaltyScreen(appointments: _appointments),
      AdminScreen(
        appointments: _appointments,
        services: _services,
        isLoggedIn: _adminLoggedIn,
        onLogin: () => setState(() => _adminLoggedIn = true),
        onLogout: () => setState(() => _adminLoggedIn = false),
        onStatusChanged: _updateAppointmentStatus,
        onServiceAdded: _addService,
      ),
    ];

    return Scaffold(
      body: SafeArea(
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          child: pages[_tab],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        onDestinationSelected: (index) => setState(() => _tab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'رزرو'),
          NavigationDestination(icon: Icon(Icons.photo_library_outlined), selectedIcon: Icon(Icons.photo_library), label: 'نمونه‌کار'),
          NavigationDestination(icon: Icon(Icons.stars_outlined), selectedIcon: Icon(Icons.stars), label: 'باشگاه'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), selectedIcon: Icon(Icons.admin_panel_settings), label: 'مدیریت'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    required this.appointments,
    required this.services,
    required this.onBookNow,
  });

  final List<Appointment> appointments;
  final List<ServiceItem> services;
  final VoidCallback onBookNow;

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final todayAppointments = appointments.where((item) => sameDate(item.date, today)).length;
    final freeSlots = max(0, 18 - todayAppointments);
    final nextAppointments = appointments
        .where((item) => sameDate(item.date, today) && item.status != AppointmentStatus.cancelled)
        .toList()
      ..sort((a, b) => a.time.compareTo(b.time));

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
      children: [
        const BrandHeader(),
        const SizedBox(height: 18),
        HeroCard(freeSlots: freeSlots, onBookNow: onBookNow),
        const SizedBox(height: 18),
        Row(
          children: [
            Expanded(
              child: StatCard(
                title: 'نوبت امروز',
                value: faNumber(todayAppointments.toString()),
                icon: Icons.today,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatCard(
                title: 'خدمت فعال',
                value: faNumber(services.length.toString()),
                icon: Icons.spa,
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),
        SectionTitle(title: 'نوبت‌های نزدیک', action: 'صف زنده'),
        const SizedBox(height: 10),
        if (nextAppointments.isEmpty)
          const EmptyState(message: 'برای امروز هنوز نوبتی ثبت نشده است.')
        else
          ...nextAppointments.take(4).map((item) => AppointmentMiniCard(appointment: item)),
        const SizedBox(height: 18),
        const SectionTitle(title: 'خدمات منتخب'),
        const SizedBox(height: 10),
        SizedBox(
          height: 138,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) => ServicePreviewCard(service: services[index]),
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemCount: services.length,
          ),
        ),
        const SizedBox(height: 18),
        const ViralBox(),
      ],
    );
  }
}

class BrandHeader extends StatelessWidget {
  const BrandHeader({super.key});

  @override
  Widget build(BuildContext context) {
    const badge = 'VIP';
    return Row(
      children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(
              colors: [Color(0xFF0D0B08), Color(0xFF40331D)],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
            boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 18, offset: Offset(0, 10))],
          ),
          child: const Icon(Icons.content_cut, color: Color(0xFFD8A847), size: 28),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('پیرایش مسلم', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFF12100D))),
              SizedBox(height: 2),
              Text('نوبت آنلاین اصلاح و پیرایش', style: TextStyle(fontSize: 13, color: Color(0xFF766C5A))),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: const Color(0xFFECDFC7),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Row(
            children: [
              const Icon(Icons.verified, color: Color(0xFFD8A847), size: 16),
              const SizedBox(width: 4),
              Text(badge, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF4B3514))),
            ],
          ),
        ),
      ],
    );
  }
}

class HeroCard extends StatelessWidget {
  const HeroCard({super.key, required this.freeSlots, required this.onBookNow});

  final int freeSlots;
  final VoidCallback onBookNow;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(
          colors: [Color(0xFF14110D), Color(0xFF3B2E1B), Color(0xFF12100D)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        boxShadow: const [BoxShadow(color: Color(0x3312100D), blurRadius: 28, offset: Offset(0, 16))],
      ),
      child: Stack(
        children: [
          Positioned(
            left: -14,
            bottom: -16,
            child: Icon(Icons.content_cut, size: 120, color: Colors.white.withOpacity(.055)),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.1),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: Colors.white.withOpacity(.16)),
                ),
                child: Text(
                  'امروز فقط ${faNumber(freeSlots.toString())} نوبت خالی مانده',
                  style: const TextStyle(color: Color(0xFFFFE2A7), fontWeight: FontWeight.w800, fontSize: 13),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'بدون تماس، بدون معطلی\nنوبتت رو بگیر و سر وقت بیا',
                style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, height: 1.45),
              ),
              const SizedBox(height: 8),
              Text(
                'رزرو سریع، صف زنده، امتیاز مشتری ثابت و نمونه‌کارهای به‌روز پیرایش مسلم.',
                style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 13.5, height: 1.7),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  FilledButton.icon(
                    onPressed: onBookNow,
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFD8A847),
                      foregroundColor: const Color(0xFF12100D),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    icon: const Icon(Icons.calendar_month),
                    label: const Text('رزرو نوبت', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                  const SizedBox(width: 10),
                  OutlinedButton(
                    onPressed: onBookNow,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: BorderSide(color: Colors.white.withOpacity(.22)),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: const Text('نوبت فوری امروز'),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class BookingScreen extends StatefulWidget {
  const BookingScreen({
    super.key,
    required this.services,
    required this.appointments,
    required this.onBooked,
  });

  final List<ServiceItem> services;
  final List<Appointment> appointments;
  final ValueChanged<Appointment> onBooked;

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final _nameController = TextEditingController();
  final _mobileController = TextEditingController();
  int _serviceIndex = 0;
  DateTime _selectedDate = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day);
  String? _selectedTime;

  @override
  void dispose() {
    _nameController.dispose();
    _mobileController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final service = widget.services[_serviceIndex];
    final slots = _availableSlotsFor(_selectedDate);

    return ListView(
      key: const ValueKey('booking'),
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
      children: [
        const BrandHeader(),
        const SizedBox(height: 18),
        const Text('رزرو نوبت', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF12100D))),
        const SizedBox(height: 6),
        const Text('خدمت، روز و ساعت موردنظر را انتخاب کن. نوبت بعد از ثبت در پنل مدیریت دیده می‌شود.', style: TextStyle(color: Color(0xFF766C5A), height: 1.7)),
        const SizedBox(height: 18),
        TextField(
          controller: _nameController,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(prefixIcon: Icon(Icons.person), labelText: 'نام مشتری'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _mobileController,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(prefixIcon: Icon(Icons.phone_android), labelText: 'شماره موبایل'),
        ),
        const SizedBox(height: 18),
        const SectionTitle(title: 'انتخاب خدمت'),
        const SizedBox(height: 10),
        SizedBox(
          height: 154,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: widget.services.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, index) {
              final item = widget.services[index];
              final selected = index == _serviceIndex;
              return GestureDetector(
                onTap: () => setState(() => _serviceIndex = index),
                child: ServiceSelectCard(service: item, selected: selected),
              );
            },
          ),
        ),
        const SizedBox(height: 18),
        const SectionTitle(title: 'انتخاب روز'),
        const SizedBox(height: 10),
        SizedBox(
          height: 74,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              final day = DateTime.now().add(Duration(days: index));
              final date = DateTime(day.year, day.month, day.day);
              final selected = sameDate(date, _selectedDate);
              return ChoiceChip(
                selected: selected,
                onSelected: (_) => setState(() {
                  _selectedDate = date;
                  _selectedTime = null;
                }),
                label: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(index == 0 ? 'امروز' : weekDayName(date.weekday), style: const TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text('${faNumber(date.day.toString())}/${faNumber(date.month.toString())}', style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                ),
              );
            },
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemCount: 7,
          ),
        ),
        const SizedBox(height: 18),
        const SectionTitle(title: 'ساعت‌های آزاد'),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: slots.map((time) {
            final selected = _selectedTime == time;
            return ChoiceChip(
              selected: selected,
              label: Text(faNumber(time)),
              onSelected: (_) => setState(() => _selectedTime = time),
            );
          }).toList(),
        ),
        const SizedBox(height: 20),
        BookingSummary(service: service, date: _selectedDate, time: _selectedTime),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _submitBooking,
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFF12100D),
            foregroundColor: Colors.white,
            minimumSize: const Size.fromHeight(56),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
          icon: const Icon(Icons.check_circle),
          label: const Text('ثبت نوبت', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        ),
      ],
    );
  }

  List<String> _availableSlotsFor(DateTime date) {
    final booked = widget.appointments
        .where((item) => sameDate(item.date, date) && item.status != AppointmentStatus.cancelled)
        .map((item) => item.time)
        .toSet();
    final slots = <String>[];
    for (var hour = 10; hour <= 21; hour++) {
      for (final minute in [0, 30]) {
        final time = '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
        if (!booked.contains(time)) slots.add(time);
      }
    }
    return slots;
  }

  void _submitBooking() {
    final name = _nameController.text.trim();
    final mobile = _mobileController.text.trim();
    if (name.length < 2 || mobile.length < 8 || _selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('نام، شماره موبایل و ساعت نوبت را کامل وارد کن.')),
      );
      return;
    }
    final service = widget.services[_serviceIndex];
    final code = 1000 + Random().nextInt(8999);
    widget.onBooked(Appointment(
      id: 'M-$code',
      customerName: name,
      mobile: mobile,
      serviceName: service.title,
      price: service.price,
      date: _selectedDate,
      time: _selectedTime!,
      status: AppointmentStatus.pending,
      points: 0,
    ));
    _nameController.clear();
    _mobileController.clear();
    setState(() => _selectedTime = null);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('نوبت ثبت شد و در انتظار تایید مدیریت است.')),
    );
  }
}

class GalleryScreen extends StatelessWidget {
  const GalleryScreen({super.key, required this.items});

  final List<GalleryItem> items;

  @override
  Widget build(BuildContext context) {
    return ListView(
      key: const ValueKey('gallery'),
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
      children: [
        const BrandHeader(),
        const SizedBox(height: 18),
        const Text('نمونه‌کارها', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        const Text('گالری مدل‌ها برای انتخاب سریع قبل از رزرو نوبت.', style: TextStyle(color: Color(0xFF766C5A))),
        const SizedBox(height: 18),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: .86,
          ),
          itemBuilder: (context, index) => GalleryCard(item: items[index], index: index),
        ),
      ],
    );
  }
}

class LoyaltyScreen extends StatelessWidget {
  const LoyaltyScreen({super.key, required this.appointments});

  final List<Appointment> appointments;

  @override
  Widget build(BuildContext context) {
    final approved = appointments.where((item) => item.status == AppointmentStatus.approved).length;
    final points = appointments.fold<int>(0, (sum, item) => sum + item.points);
    final nextReward = max(0, 50 - points);

    return ListView(
      key: const ValueKey('loyalty'),
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
      children: [
        const BrandHeader(),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            gradient: const LinearGradient(
              colors: [Color(0xFF12100D), Color(0xFF463416)],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('باشگاه مشتریان مسلم', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('هر نوبت تایید شده، امتیاز می‌گیرد. مشتری ثابت، تخفیف و هدیه اختصاصی می‌گیرد.', style: TextStyle(color: Colors.white.withOpacity(.72), height: 1.8)),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(child: DarkStat(title: 'امتیاز کل', value: faNumber(points.toString()))),
                  const SizedBox(width: 10),
                  Expanded(child: DarkStat(title: 'نوبت تایید', value: faNumber(approved.toString()))),
                ],
              ),
              const SizedBox(height: 14),
              LinearProgressIndicator(
                value: points >= 50 ? 1 : points / 50,
                minHeight: 10,
                borderRadius: BorderRadius.circular(999),
                backgroundColor: Colors.white.withOpacity(.14),
                valueColor: const AlwaysStoppedAnimation(Color(0xFFD8A847)),
              ),
              const SizedBox(height: 10),
              Text(
                points >= 50 ? 'هدیه فعال شد: تخفیف مشتری ثابت' : '${faNumber(nextReward.toString())} امتیاز تا هدیه بعدی',
                style: const TextStyle(color: Color(0xFFFFE2A7), fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const SectionTitle(title: 'سطح‌ها'),
        const SizedBox(height: 10),
        const LoyaltyTierCard(title: 'برنزی', points: '۰ تا ۴۹', reward: 'ثبت امتیاز و پیامک یادآوری'),
        const LoyaltyTierCard(title: 'نقره‌ای', points: '۵۰ تا ۹۹', reward: 'تخفیف اصلاح ریش'),
        const LoyaltyTierCard(title: 'طلایی', points: '۱۰۰ به بالا', reward: 'اولویت نوبت و تخفیف ویژه'),
        const SizedBox(height: 16),
        const InviteCard(),
      ],
    );
  }
}

class AdminScreen extends StatefulWidget {
  const AdminScreen({
    super.key,
    required this.appointments,
    required this.services,
    required this.isLoggedIn,
    required this.onLogin,
    required this.onLogout,
    required this.onStatusChanged,
    required this.onServiceAdded,
  });

  final List<Appointment> appointments;
  final List<ServiceItem> services;
  final bool isLoggedIn;
  final VoidCallback onLogin;
  final VoidCallback onLogout;
  final void Function(Appointment appointment, AppointmentStatus status) onStatusChanged;
  final ValueChanged<ServiceItem> onServiceAdded;

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final _userController = TextEditingController();
  final _passController = TextEditingController();
  final _serviceTitle = TextEditingController();
  final _servicePrice = TextEditingController();
  final _serviceDuration = TextEditingController();

  @override
  void dispose() {
    _userController.dispose();
    _passController.dispose();
    _serviceTitle.dispose();
    _servicePrice.dispose();
    _serviceDuration.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isLoggedIn) return _buildLogin(context);
    final today = DateTime.now();
    final todayAppointments = widget.appointments.where((item) => sameDate(item.date, today)).toList()
      ..sort((a, b) => a.time.compareTo(b.time));
    final pending = widget.appointments.where((item) => item.status == AppointmentStatus.pending).length;

    return ListView(
      key: const ValueKey('admin'),
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
      children: [
        Row(
          children: [
            const Expanded(child: BrandHeader()),
            IconButton.filledTonal(onPressed: widget.onLogout, icon: const Icon(Icons.logout)),
          ],
        ),
        const SizedBox(height: 18),
        Row(
          children: [
            Expanded(child: StatCard(title: 'نوبت امروز', value: faNumber(todayAppointments.length.toString()), icon: Icons.today)),
            const SizedBox(width: 10),
            Expanded(child: StatCard(title: 'در انتظار تایید', value: faNumber(pending.toString()), icon: Icons.pending_actions)),
          ],
        ),
        const SizedBox(height: 18),
        const SectionTitle(title: 'مدیریت نوبت‌های امروز'),
        const SizedBox(height: 10),
        if (todayAppointments.isEmpty)
          const EmptyState(message: 'برای امروز نوبتی ثبت نشده است.')
        else
          ...todayAppointments.map((item) => AdminAppointmentCard(
                appointment: item,
                onApprove: () => widget.onStatusChanged(item, AppointmentStatus.approved),
                onCancel: () => widget.onStatusChanged(item, AppointmentStatus.cancelled),
              )),
        const SizedBox(height: 18),
        const SectionTitle(title: 'همه نوبت‌ها'),
        const SizedBox(height: 10),
        ...widget.appointments.map((item) => AdminAppointmentCard(
              appointment: item,
              compact: true,
              onApprove: () => widget.onStatusChanged(item, AppointmentStatus.approved),
              onCancel: () => widget.onStatusChanged(item, AppointmentStatus.cancelled),
            )),
        const SizedBox(height: 18),
        const SectionTitle(title: 'افزودن خدمت جدید'),
        const SizedBox(height: 10),
        _buildServiceForm(context),
      ],
    );
  }

  Widget _buildLogin(BuildContext context) {
    return ListView(
      key: const ValueKey('login'),
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
      children: [
        const BrandHeader(),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 22, offset: Offset(0, 12))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('ورود مدیریت', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('برای دمو: نام کاربری admin و رمز admin123 است.', style: TextStyle(color: Color(0xFF766C5A))),
              const SizedBox(height: 18),
              TextField(controller: _userController, decoration: const InputDecoration(prefixIcon: Icon(Icons.person), labelText: 'نام کاربری')),
              const SizedBox(height: 12),
              TextField(controller: _passController, obscureText: true, decoration: const InputDecoration(prefixIcon: Icon(Icons.lock), labelText: 'رمز عبور')),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: _tryLogin,
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(54),
                  backgroundColor: const Color(0xFF12100D),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                ),
                icon: const Icon(Icons.admin_panel_settings),
                label: const Text('ورود به پنل', style: TextStyle(fontWeight: FontWeight.w900)),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildServiceForm(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
      child: Column(
        children: [
          TextField(controller: _serviceTitle, decoration: const InputDecoration(labelText: 'نام خدمت', prefixIcon: Icon(Icons.design_services))),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: TextField(controller: _servicePrice, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت تومان'))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: _serviceDuration, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'مدت دقیقه'))),
            ],
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _addService,
            icon: const Icon(Icons.add),
            label: const Text('افزودن خدمت'),
          ),
        ],
      ),
    );
  }

  void _tryLogin() {
    if (_userController.text.trim() == 'admin' && _passController.text == 'admin123') {
      widget.onLogin();
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نام کاربری یا رمز اشتباه است.')));
  }

  void _addService() {
    final title = _serviceTitle.text.trim();
    final price = int.tryParse(_servicePrice.text.trim()) ?? 0;
    final duration = int.tryParse(_serviceDuration.text.trim()) ?? 30;
    if (title.length < 2 || price <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نام خدمت و قیمت معتبر وارد کن.')));
      return;
    }
    widget.onServiceAdded(ServiceItem(title, 'خدمت اختصاصی پیرایش مسلم', price, duration, Icons.add_business));
    _serviceTitle.clear();
    _servicePrice.clear();
    _serviceDuration.clear();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خدمت جدید اضافه شد.')));
  }
}

class ServicePreviewCard extends StatelessWidget {
  const ServicePreviewCard({super.key, required this.service});

  final ServiceItem service;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 180,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(backgroundColor: const Color(0xFFF4E7CC), child: Icon(service.icon, color: const Color(0xFF6E4D1E))),
          const Spacer(),
          Text(service.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 4),
          Text('${money(service.price)} تومان', style: const TextStyle(color: Color(0xFF766C5A), fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class ServiceSelectCard extends StatelessWidget {
  const ServiceSelectCard({super.key, required this.service, required this.selected});

  final ServiceItem service;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      width: 205,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: selected ? const Color(0xFF12100D) : Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: selected ? const Color(0xFFD8A847) : Colors.transparent, width: 1.4),
        boxShadow: const [BoxShadow(color: Color(0x0F000000), blurRadius: 16, offset: Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(backgroundColor: selected ? const Color(0xFFD8A847) : const Color(0xFFF4E7CC), child: Icon(service.icon, color: selected ? const Color(0xFF12100D) : const Color(0xFF6E4D1E))),
              const Spacer(),
              if (selected) const Icon(Icons.check_circle, color: Color(0xFFD8A847)),
            ],
          ),
          const Spacer(),
          Text(service.title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: selected ? Colors.white : const Color(0xFF12100D))),
          const SizedBox(height: 4),
          Text(service.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: selected ? Colors.white70 : const Color(0xFF766C5A))),
          const SizedBox(height: 8),
          Text('${money(service.price)} تومان • ${faNumber(service.durationMinutes.toString())} دقیقه', style: TextStyle(fontWeight: FontWeight.w800, color: selected ? const Color(0xFFFFE2A7) : const Color(0xFF6E4D1E))),
        ],
      ),
    );
  }
}

class BookingSummary extends StatelessWidget {
  const BookingSummary({super.key, required this.service, required this.date, required this.time});

  final ServiceItem service;
  final DateTime date;
  final String? time;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF4E7CC),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE2C894)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.receipt_long, color: Color(0xFF6E4D1E)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('خلاصه نوبت', style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('${service.title} • ${money(service.price)} تومان'),
                Text('${weekDayName(date.weekday)} ${faNumber(date.day.toString())}/${faNumber(date.month.toString())} ساعت ${time == null ? 'انتخاب نشده' : faNumber(time!)}'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AppointmentMiniCard extends StatelessWidget {
  const AppointmentMiniCard({super.key, required this.appointment});

  final Appointment appointment;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: const Color(0xFFF4E7CC), child: Text(faNumber(appointment.time), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: Color(0xFF6E4D1E)))),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(appointment.customerName, style: const TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 2),
              Text(appointment.serviceName, style: const TextStyle(fontSize: 12, color: Color(0xFF766C5A))),
            ]),
          ),
          StatusBadge(status: appointment.status),
        ],
      ),
    );
  }
}

class AdminAppointmentCard extends StatelessWidget {
  const AdminAppointmentCard({
    super.key,
    required this.appointment,
    required this.onApprove,
    required this.onCancel,
    this.compact = false,
  });

  final Appointment appointment;
  final VoidCallback onApprove;
  final VoidCallback onCancel;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(color: const Color(0xFFF4E7CC), borderRadius: BorderRadius.circular(18)),
                child: Center(child: Text(faNumber(appointment.time), style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF6E4D1E)))),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(appointment.customerName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5)),
                  const SizedBox(height: 3),
                  Text('${appointment.serviceName} • ${money(appointment.price)} تومان', style: const TextStyle(color: Color(0xFF766C5A), fontSize: 12.5)),
                  const SizedBox(height: 3),
                  Text('${faNumber(appointment.mobile)} • ${dateLabel(appointment.date)}', style: const TextStyle(color: Color(0xFF9B907C), fontSize: 12)),
                ]),
              ),
              StatusBadge(status: appointment.status),
            ],
          ),
          if (!compact || appointment.status == AppointmentStatus.pending) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onCancel,
                    icon: const Icon(Icons.close),
                    label: const Text('لغو'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: onApprove,
                    icon: const Icon(Icons.check),
                    label: const Text('تایید'),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class StatusBadge extends StatelessWidget {
  const StatusBadge({super.key, required this.status});

  final AppointmentStatus status;

  @override
  Widget build(BuildContext context) {
    Color color;
    String text;
    switch (status) {
      case AppointmentStatus.pending:
        color = const Color(0xFFB47A00);
        text = 'انتظار';
        break;
      case AppointmentStatus.approved:
        color = const Color(0xFF197245);
        text = 'تایید';
        break;
      case AppointmentStatus.cancelled:
        color = const Color(0xFFB3261E);
        text = 'لغو';
        break;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(999)),
      child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
    );
  }
}

class GalleryCard extends StatelessWidget {
  const GalleryCard({super.key, required this.item, required this.index});

  final GalleryItem item;
  final int index;

  @override
  Widget build(BuildContext context) {
    final dark = index.isEven;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: LinearGradient(
          colors: dark ? const [Color(0xFF12100D), Color(0xFF493917)] : const [Color(0xFFFFFFFF), Color(0xFFF2E1BE)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        boxShadow: const [BoxShadow(color: Color(0x10000000), blurRadius: 18, offset: Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(item.icon, color: dark ? const Color(0xFFD8A847) : const Color(0xFF6E4D1E), size: 42),
          const Spacer(),
          Text(item.title, style: TextStyle(color: dark ? Colors.white : const Color(0xFF12100D), fontSize: 17, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(item.subtitle, style: TextStyle(color: dark ? Colors.white70 : const Color(0xFF766C5A), fontSize: 12.5, height: 1.55)),
        ],
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.title, required this.value, required this.icon});

  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: const Color(0xFFF4E7CC), child: Icon(icon, color: const Color(0xFF6E4D1E))),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              Text(title, style: const TextStyle(color: Color(0xFF766C5A), fontSize: 12)),
            ]),
          ),
        ],
      ),
    );
  }
}

class DarkStat extends StatelessWidget {
  const DarkStat({super.key, required this.title, required this.value});

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.1), borderRadius: BorderRadius.circular(18)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: const TextStyle(color: Color(0xFFFFE2A7), fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 3),
        Text(title, style: TextStyle(color: Colors.white.withOpacity(.65), fontSize: 12)),
      ]),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title, this.action});

  final String title;
  final String? action;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF12100D))),
        const Spacer(),
        if (action != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: const Color(0xFFF4E7CC), borderRadius: BorderRadius.circular(999)),
            child: Text(action!, style: const TextStyle(color: Color(0xFF6E4D1E), fontWeight: FontWeight.w800, fontSize: 12)),
          ),
      ],
    );
  }
}

class ViralBox extends StatelessWidget {
  const ViralBox({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: const Color(0xFFE7D8B9)),
      ),
      child: const Row(
        children: [
          CircleAvatar(backgroundColor: Color(0xFF12100D), child: Icon(Icons.qr_code_2, color: Color(0xFFD8A847))),
          SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('قابلیت تبلیغاتی آماده', style: TextStyle(fontWeight: FontWeight.w900)),
              SizedBox(height: 4),
              Text('QR رزرو روی آینه نصب می‌شود؛ مشتری اسکن می‌کند و نوبت بعدی را همان‌جا می‌گیرد.', style: TextStyle(color: Color(0xFF766C5A), height: 1.55)),
            ]),
          ),
        ],
      ),
    );
  }
}

class LoyaltyTierCard extends StatelessWidget {
  const LoyaltyTierCard({super.key, required this.title, required this.points, required this.reward});

  final String title;
  final String points;
  final String reward;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
      child: Row(
        children: [
          const Icon(Icons.workspace_premium, color: Color(0xFFD8A847)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            Text(reward, style: const TextStyle(color: Color(0xFF766C5A), fontSize: 12.5)),
          ])),
          Text(points, style: const TextStyle(color: Color(0xFF6E4D1E), fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class InviteCard extends StatelessWidget {
  const InviteCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26)),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(color: const Color(0xFFF4E7CC), borderRadius: BorderRadius.circular(18)),
            child: const Icon(Icons.card_giftcard, color: Color(0xFF6E4D1E)),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('کد دعوت: MOSLEM10', style: TextStyle(fontWeight: FontWeight.w900)),
              SizedBox(height: 4),
              Text('دوستت رو دعوت کن؛ هر دو تخفیف بگیرید.', style: TextStyle(color: Color(0xFF766C5A))),
            ]),
          ),
        ],
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: Color(0xFF766C5A)),
          const SizedBox(width: 10),
          Expanded(child: Text(message, style: const TextStyle(color: Color(0xFF766C5A)))),
        ],
      ),
    );
  }
}

class ServiceItem {
  ServiceItem(this.title, this.subtitle, this.price, this.durationMinutes, this.icon);

  final String title;
  final String subtitle;
  final int price;
  final int durationMinutes;
  final IconData icon;
}

class GalleryItem {
  const GalleryItem(this.title, this.subtitle, this.icon);

  final String title;
  final String subtitle;
  final IconData icon;
}

enum AppointmentStatus { pending, approved, cancelled }

class Appointment {
  Appointment({
    required this.id,
    required this.customerName,
    required this.mobile,
    required this.serviceName,
    required this.price,
    required this.date,
    required this.time,
    required this.status,
    required this.points,
  });

  final String id;
  final String customerName;
  final String mobile;
  final String serviceName;
  final int price;
  final DateTime date;
  final String time;
  final AppointmentStatus status;
  final int points;

  Appointment copyWith({AppointmentStatus? status, int? points}) {
    return Appointment(
      id: id,
      customerName: customerName,
      mobile: mobile,
      serviceName: serviceName,
      price: price,
      date: date,
      time: time,
      status: status ?? this.status,
      points: points ?? this.points,
    );
  }
}

bool sameDate(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

String weekDayName(int weekday) {
  switch (weekday) {
    case DateTime.saturday:
      return 'شنبه';
    case DateTime.sunday:
      return 'یکشنبه';
    case DateTime.monday:
      return 'دوشنبه';
    case DateTime.tuesday:
      return 'سه‌شنبه';
    case DateTime.wednesday:
      return 'چهارشنبه';
    case DateTime.thursday:
      return 'پنجشنبه';
    default:
      return 'جمعه';
  }
}

String dateLabel(DateTime date) => '${weekDayName(date.weekday)} ${faNumber(date.day.toString())}/${faNumber(date.month.toString())}';

String money(int value) {
  final chars = value.toString().split('').reversed.toList();
  final parts = <String>[];
  for (var i = 0; i < chars.length; i += 3) {
    parts.add(chars.skip(i).take(3).toList().reversed.join());
  }
  return faNumber(parts.reversed.join(','));
}

String faNumber(String input) {
  const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  var result = input;
  for (var i = 0; i < en.length; i++) {
    result = result.replaceAll(en[i], fa[i]);
  }
  return result;
}
