# پیرایش مسلم | اپ نوبت‌دهی اختصاصی

نسخه v1 یک اپ Flutter فارسی و راست‌چین برای رزرو نوبت آرایشگاه «پیرایش مسلم» است. این نسخه عمومی و مخصوص ارائه مستقیم به مشتری است.

## امکانات نسخه فعلی

- صفحه اصلی برندینگ‌شده با حس لوکس مشکی/طلایی
- رزرو نوبت با انتخاب خدمت، روز و ساعت
- نمایش ساعت‌های آزاد و جلوگیری از انتخاب نوبت تکراری
- پنل مدیریت داخلی
- تایید یا لغو نوبت‌ها
- افزودن خدمت جدید از پنل مدیریت
- گالری نمونه‌کارها
- باشگاه مشتریان و امتیازدهی
- کد دعوت MOSLEM10
- آماده برای خروجی APK و AAB عمومی

## ورود پنل مدیریت

نام کاربری:

```text
admin
```

رمز عبور:

```text
admin123
```

## اجرا در Android Studio

```bash
flutter pub get
flutter run
```

اگر پوشه‌های پلتفرم کامل نبودند:

```bash
flutter create --platforms=android --org ir.pirayeshmoslem --project-name pirayesh_moslem_booking .
python3 scripts/prepare_android.py
flutter run
```

## ساخت خروجی دستی

```bash
flutter pub get
flutter build apk --release
flutter build appbundle --release
```

## ساخت خروجی با GitHub Actions

Workflow آماده داخل مسیر زیر قرار دارد:

```text
.github/workflows/build-release.yml
```

بعد از Push روی شاخه main یا اجرای دستی workflow، خروجی‌های APK و AAB در بخش Artifacts ساخته می‌شوند.

## نکته فنی

این نسخه برای دمو و شروع پروژه، داده‌ها را داخل حافظه اپ نگه می‌دارد. برای نسخه تجاری واقعی باید بک‌اند اضافه شود تا مشتری‌ها از گوشی خودشان نوبت ثبت کنند و مدیریت همان لحظه ببیند.

پیشنهاد نسخه بعدی: Supabase یا Firebase برای رزرو آنلاین واقعی، پیامک یادآوری، بیعانه، لینک اختصاصی و QR رزرو.
